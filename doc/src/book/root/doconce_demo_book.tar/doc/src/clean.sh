#!/bin/sh
doconce clean
rm -rf Trash automake*

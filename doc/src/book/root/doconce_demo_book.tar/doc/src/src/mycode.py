import numpy as np

def f(x):
    return 42*x

def g(x):
    """The derivative of f."""
    return 42

## Files in this directory

 * `book.do.txt`: main file for book
 * `*.do.txt`: chapters for the book
 * `make.sh`: compile to PDF
 * `make_html.sh`: compile to HTML (Bootstrap and Sphinx)
 * `src`: computer source code for the book
 * `clean.sh`: remove all redundant files

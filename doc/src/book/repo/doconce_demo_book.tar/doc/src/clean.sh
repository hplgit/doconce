#!/bin/sh
doconce clean
rm -rf Trash automake* newcommands_keep* *-book*.log *book*.html *book*.pdf *book*.aux* *book*.tex papers.bib newcommands.tex

This theme is taken from http://scipy-lectures.github.com/.
From LICENSE.rst in that repo:

License
========

All code and material is licensed under a

Creative Commons Attribution 3.0 United States License (CC-by)
http://creativecommons.org/licenses/by/3.0/us

See the AUTHORS.rst file for a list of contributors.

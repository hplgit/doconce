# CSSS
### CSS-based SlideShow System

There is a [sample slideshow](http://lea.verou.me/csss/sample-slideshow.html) but it's not really up to date. Better check out some of my existing slide decks:

- http://github.com/leaverou/css-variables
- https://github.com/leaverou/jsux
- https://github.com/leaverou/html-secrets
- https://github.com/leaverou/missing-slice
- and many others...
